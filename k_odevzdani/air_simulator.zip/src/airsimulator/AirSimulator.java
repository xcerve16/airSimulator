/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package airsimulator;

import airsimulator.GUI.MainMenu;

/**
 *
 * @author Adam
 */
public class AirSimulator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MainMenu mainMenu = new MainMenu();
    }
    
}
